import numpy as np
import nnfs
from nnfs.datasets import spiral_data

nnfs.init() #Generates pseudo-random number based on seed. Seed can be any number.

# about the data : predicting whether a server will fail or not

# SAMPLE DATA, TRAINING DATA SET (3 SAMPLES)
#each input value is reading from a sensor, for example : temp sensor, humidity sensor, etc. The values are from unique sensors at a particular times



#defining 2 hidden layers of this simple neural network
#need to initalise weights and biases as this a new neural network and no data is being loaded
#weights will be random values between -1 to +1, but the smaller the range the better. Why? to scale down the data
#biases: tend to be initialised to 0 (but not always, if the input values are too small i.e network will be dead)
class Layer_Dense:
	#initialising method
	def __init__(self, n_inputs, n_neurons):
		self.weights = 0.10* np.random.randn(n_inputs, n_neurons) #variables defining the shape (I have multiplied it by 0.10 to scale the values down for simplicity purposes)
		self.biases = np.zeros((1, n_neurons))
	#forward pass method	
	def forward(self, inputs):
		self.output =np.dot(inputs, self.weights) + self.biases #we compute the dot product of our inputs & weights and add a bias term (Dot Product)

#RELU (Rectified Linear Unit Function) activation function is a very popular activation function to use - In simple terms, mimicking a neuron firing off in the brain
class Acivation_ReLU:
	def forward(self, inputs):
		self.output = np.maximum(0,inputs) #concise way of writing the ReLU function

class Activation_Softmax:
	def forward(self, inputs):
		exp_values = np.exp(inputs - np.max(inputs, axis=1, keepdims=True))
		probabilities = exp_values / np.sum(exp_values, axis=1, keepdims=True)
		self.output = probabilities

class Loss:
    def calculate(self, output, y):
        sample_losses = self.forward(output, y)
        data_loss = np.mean(sample_losses)
        return data_loss

class Loss_CategoricalCrossentropy(Loss):
    def forward(self, y_pred, y_true):
        samples = len(y_pred)
        y_pred_clipped = np.clip(y_pred, 1e-7, 1-1e-7)

        if len(y_true.shape) == 1:
            correct_confidences = y_pred_clipped[range(samples), y_true]

        elif len(y_true.shape) == 2:
            correct_confidences = np.sum(y_pred_clipped*y_true, axis=1)

        negative_log_likelihoods = -np.log(correct_confidences)
        return negative_log_likelihoods

X, y = spiral_data(samples=100, classes=3)

dense1=Layer_Dense(2,3) #shape i.e number of features i.e size of each input and number of neurons
activation1=Acivation_ReLU()

dense2=Layer_Dense(3,3) #shape i.e number of features i.e size of each input and number of neurons
activation2=Activation_Softmax()

dense1.forward(X)
activation1.forward(dense1.output)

dense2.forward(activation1.output)  
activation2.forward(dense2 .output)

print(activation2.output[:5])

loss_function = Loss_CategoricalCrossentropy()
loss = loss_function.calculate(activation2.output, y)

print("Loss:", loss)